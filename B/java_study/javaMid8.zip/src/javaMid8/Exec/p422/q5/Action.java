package javaMid8.Exec.p422.q5;

public interface Action {
   public void work();
}
