package javaMid8.Exec.p422.q4;

public class CarExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Car myCar = new Car();
        
        Car.Tire tire = myCar.new Tire();
        
        Car.Engine engine = new  Car.Engine();
	}

}
