package javaMid8.Exec.p422.q4;

public class Car {
   class Tire { }
   static class Engine { }
}
