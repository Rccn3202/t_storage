package javaMid8.Exec.p422.q6;

public interface Vehicle {
    public void run();
}
