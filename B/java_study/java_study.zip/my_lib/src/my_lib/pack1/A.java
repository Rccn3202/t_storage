package my_lib.pack1;

public class A {
   public void method() {
	   System.out.println("A-method ����");
   }
}
