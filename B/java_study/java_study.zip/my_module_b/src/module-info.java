module my_module_b {
	exports pack3;
	exports pack4;
}