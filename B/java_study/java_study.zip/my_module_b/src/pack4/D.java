package pack4;

public class D {
	 public void method() {
		   System.out.println("D-method����");
	   }
}
