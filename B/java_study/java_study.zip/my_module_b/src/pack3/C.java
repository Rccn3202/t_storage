package pack3;

public class C {
	 public void method() {
		   System.out.println("C-method����");
	   }
}
