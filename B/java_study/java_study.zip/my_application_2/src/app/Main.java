package app;

import pack1.A;
import pack2.B;
import pack3.C;
// import pack30.CC;

public class Main {

	public static void main(String[] args) {
		A a =new A();
		a.method();
		
		B b = new B();
		b.method();

		C c = new C();
		c.method();
		
//		CC cc = new CC();
//		cc.method();
		
	}

}
