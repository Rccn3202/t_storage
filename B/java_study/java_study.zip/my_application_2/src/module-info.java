module my_application_2 {
	requires my_module_a;
	requires my_module_b;
}