package pack30;

public class CC {
   public void method() {
	   System.out.println("CC-Method");
   }
}
