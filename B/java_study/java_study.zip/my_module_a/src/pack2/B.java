package pack2;

public class B {
   public void method() {
	   System.out.println("B-method����");
   }
}
