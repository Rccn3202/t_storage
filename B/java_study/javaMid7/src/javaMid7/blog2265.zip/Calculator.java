package javaMid7.blog2265;

public class Calculator {
    int width;
    int height;
    
    public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	
	void calc() { 
    	
    };
    
    void printA()  {
    	System.out.println("���δ� " + width);
    	System.out.println("���δ� " + height);
    }
    
}
