package javaMid7.blog2265;

public class AnnonyEx {

	public static void main(String[] args) {
	
        CalculatorBusiness cb = new CalculatorBusiness();
        cb.ca1.calc();
        cb.ca2.calc();
        cb.ca3.calc();
  /*      
        CalculatorBusiness cb2 = new CalculatorBusiness();
    //    cb2.ca1.calc();
        
        CalculatorBusiness cb3 = new CalculatorBusiness();
     //   cb3.ca2.calc();
        
        CalculatorBusiness cb4 = new CalculatorBusiness();
        cb4.ca3.calc();
    */    
	}

}
