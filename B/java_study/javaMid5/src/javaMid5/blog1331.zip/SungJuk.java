package javaMid5.blog1331;

public class SungJuk {
	
   private String subject;//�����
   private int score;//����
   private int midtermExam;//�߰�����
   private int finals;//�⸻����
   private int performanceEvalution;//������
   
   void printAll() {
	   //���� ��� 
   }
   
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public int getMidtermExam() {
		return midtermExam;
	}
	public void setMidtermExam(int midtermExam) {
		this.midtermExam = midtermExam;
	}
	public int getFinals() {
		return finals;
	}
	public void setFinals(int finals) {
		this.finals = finals;
	}
	public int getPerformanceEvalution() {
		return performanceEvalution;
	}
	public void setPerformanceEvalution(int performanceEvalution) {
		this.performanceEvalution = performanceEvalution;
	}
   
   
}
