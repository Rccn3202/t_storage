package javaMid6.p395;

public class OuterA {

}
