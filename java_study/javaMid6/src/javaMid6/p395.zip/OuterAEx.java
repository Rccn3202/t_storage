package javaMid6.p395;

public class OuterAEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
